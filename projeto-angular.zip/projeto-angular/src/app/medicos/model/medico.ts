export class medico {
    id: number;
    nome: string;
    email: string;
    crm: string;
}